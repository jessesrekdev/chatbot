
// ===== Conversation helpers =====
function getCurrentConversation() {
  return conversations.find(c => c.id === currentConversationId) || null;
}

function saveConversations() {
  localStorage.setItem("conversations", JSON.stringify(conversations));
}

function setActiveConversation(convId) {
  currentConversationId = convId;
  renderConversationMessages();
}

function renderConversationMessages() {
  chatBox.innerHTML = '';
  // Show title/subtitle for empty or new conversations
  const conv = getCurrentConversation();
  if (!conv || !conv.messages || conv.messages.length === 0) {
    chatBox.innerHTML = `
      <h1 class="title">Crazy Chat</h1>
      <p class="subtitle">This chat won't appear in history or be used to train our models. For safety purposes, we may keep a copy of this chat for up to 30 days.</p>
    `;
    return;
  }
  conv.messages.forEach(msg => {
    if (msg.fromUser) {
      appendUserMessage(msg.text, msg.attachmentsHTML || "");
    } else {
      appendBotMessage(msg.text);
    }
  });
  chatBox.scrollTop = chatBox.scrollHeight;
}

// ===== Send message via Puter & save to conversation =====
async function sendPrompt(text) {
  // If no conversation, start a new one
  if (!currentConversationId) {
    const newConv = {
      id: Date.now(),
      title: `Chat ${new Date().toLocaleString()}`,
      messages: []
    };
    conversations.unshift(newConv);
    currentConversationId = newConv.id;
    saveConversations();
    renderConversations();
  }

  // Save user message to conversation
  const conv = getCurrentConversation();
  const attachmentsHTML = attachedFilesPreview.innerHTML;
  conv.messages.push({ text, fromUser: true, attachmentsHTML });
  saveConversations();
  appendUserMessage(text, attachmentsHTML);
  attachedFilesPreview.innerHTML = "";
  fileInput.value = "";
  input.value = "";
  sendButton.style.display = "none";

  // Typing placeholder
  const typingWrapper = document.createElement("div");
  typingWrapper.className = "chat-message bot-message";
  typingWrapper.appendChild(createTypingIndicator());
  chatBox.appendChild(typingWrapper);
  chatBox.scrollTop = chatBox.scrollHeight;

  try {
    const response = await puter.ai.chat(text, { model: "gpt-5-nano", stream: true });
    let buffer = "";
    for await (const part of response) {
      buffer += part?.text || "";
    }

    // Remove typing indicator
    typingWrapper.remove();

    // Save + render styled bot message
    conv.messages.push({ text: buffer, fromUser: false });
    saveConversations();
    appendBotMessage(buffer);

  } catch (err) {
    typingWrapper.remove();
    const errorText = "❌ Failed to fetch response.";
    conv.messages.push({ text: errorText, fromUser: false });
    saveConversations();
    appendBotMessage(errorText);
  }
}
