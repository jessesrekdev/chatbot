

sendButton.addEventListener("click", () => {
  const text = input.value.trim();
  if (!text && !fileInput.files.length) return;
  sendPrompt(text);
});

// Open / close menu
menuButton.addEventListener("click", () => sideMenu.classList.add("open"));
closeMenu.addEventListener("click", () => sideMenu.classList.remove("open"));

// Telegram link
menuTelegram.addEventListener("click", () => window.open("https://t.me/jesse_pro", "_blank"));

// New Chat from menu
menuNewChat.addEventListener("click", () => {
  // Start new conversation
  const newConv = {
    id: Date.now(),
    title: `Chat ${new Date().toLocaleString()}`,
    messages: []
  };
  conversations.unshift(newConv);
  currentConversationId = newConv.id;
  saveConversations();
  renderConversations();
  renderConversationMessages();
  sideMenu.classList.remove("open");
});

// Model switch
modelSelect.addEventListener("change", (e) => console.log("Selected model:", e.target.value));


// ===== Search toggle =====
menuSearchBtn.addEventListener("click", () => {
  menuSearchSection.classList.remove("hidden");
  searchInput.focus();
});

closeSearchBtn.addEventListener("click", () => {
  menuSearchSection.classList.add("hidden");
  searchInput.value = "";
  renderConversations();
});

// ===== Live search =====
searchInput.addEventListener("input", (e) => {
  const query = e.target.value.toLowerCase();
  const filtered = conversations.filter(c =>
    c.title.toLowerCase().includes(query)
  );
  renderConversations(filtered);
});


// ===== Delete dialog =====
document.getElementById("cancelDelete").addEventListener("click", () => {
  document.getElementById("deleteDialog").classList.remove("open");
  conversationToDelete = null;
});

document.getElementById("confirmDelete").addEventListener("click", () => {
  // Remove the conversation
  conversations = conversations.filter(c => c.id !== conversationToDelete.id);
  // If the deleted conversation was active, clear chat
  if (currentConversationId === conversationToDelete.id) {
    currentConversationId = null;
    renderConversationMessages();
  }
  saveConversations();
  renderConversations();
  document.getElementById("deleteDialog").classList.remove("open");
});
