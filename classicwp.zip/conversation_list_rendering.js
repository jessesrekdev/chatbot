
// ===== Render conversations (sorted newest first) =====
function renderConversations(list = conversations) {
  conversationList.innerHTML = "";
  // Sort list by newest first (descending by id/timestamp)
  const sorted = [...list].sort((a, b) => b.id - a.id);
  sorted.forEach(conv => {
    const div = document.createElement("div");
    div.className = "conversation-item";
    div.dataset.renaming = "false";
    div.style.background = (conv.id === currentConversationId) ? "var(--bg-tertiary)" : "";
    div.innerHTML = `
      <span class="conv-title">${conv.title}</span>
      <div class="conv-actions">
        <button class="rename-btn" title="Rename">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="#10a37f" stroke-width="2" viewBox="0 0 24 24">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>
          </svg>
        </button>
        <button class="delete-btn" title="Delete">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="#ff4b5c" stroke-width="2" viewBox="0 0 24 24">
            <polyline points="3 6 5 6 21 6" />
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m5 0V4a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v2" />
          </svg>
        </button>
      </div>
    `;
    const titleSpan = div.querySelector(".conv-title");
    const convActions = div.querySelector(".conv-actions");
    const renameBtn = convActions.querySelector(".rename-btn");
    const deleteBtn = convActions.querySelector(".delete-btn");

    // Select conversation
    div.addEventListener("click", (e) => {
      // Prevent click if renaming or deleting
      if (div.dataset.renaming === "true") return;
      // Prevent click if clicking rename/delete buttons
      if (e.target.closest(".rename-btn") || e.target.closest(".delete-btn")) return;
      setActiveConversation(conv.id);
      renderConversations();
      sideMenu.classList.remove("open");
    });

    // Inline rename
    renameBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      div.dataset.renaming = "true";
      renameBtn.style.display = "none";
      deleteBtn.style.display = "none";
      const input = document.createElement("input");
      input.type = "text";
      input.value = conv.title;
      input.className = "conv-rename-input";
      input.style.width = (titleSpan.offsetWidth + 20) + "px";

      const saveBtn = document.createElement("button");
      saveBtn.className = "save-btn";
      saveBtn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="#10a37f" stroke-width="2" viewBox="0 0 24 24">
          <polyline points="20 6 9 17 4 12"/>
        </svg>`;
      saveBtn.title = "Save";

      const cancelBtn = document.createElement("button");
      cancelBtn.className = "cancel-btn";
      cancelBtn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="#ff4b5c" stroke-width="2" viewBox="0 0 24 24">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>`;
      cancelBtn.title = "Cancel";

      div.replaceChild(input, titleSpan);
      convActions.prepend(cancelBtn);
      convActions.prepend(saveBtn);

      input.focus();

      saveBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        conv.title = input.value.trim() || conv.title;
        saveConversations();
        renderConversations();
      });

      cancelBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        renderConversations();
      });
    });

    // Delete
    deleteBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      conversationToDelete = conv;
      document.getElementById("deleteMessage").textContent =
        `Do you really want to delete "${conv.title}"?`;
      document.getElementById("deleteDialog").classList.add("open");
    });

    conversationList.appendChild(div);
  });
}
