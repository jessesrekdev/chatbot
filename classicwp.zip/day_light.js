const themeToggle = document.getElementById("themeToggle");
const body = document.body;
const themeIcon = document.getElementById("themeIcon");

// ===== Dark/light theme toggle =====
themeToggle.addEventListener("click", () => {
  body.classList.toggle("dark-theme");
  body.classList.toggle("light-theme");
  themeIcon.innerHTML = body.classList.contains("dark-theme") ?
    '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>' :
    '<path d="M12 4.5a1 1 0 0 1 1 1V7a1 1 0 0 1-2 0V5.5a1 1 0 0 1 1-1Zm0 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm7-3.5a1 1 0 0 1 1 1V13a1 1 0 0 1-2 0v-.5a1 1 0 0 1 1-1ZM4.5 12a1 1 0 0 1 1-1H7a1 1 0 0 1 0 2H5.5a1 1 0 0 1-1-1Z"></path>';
});