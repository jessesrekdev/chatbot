const newChat = document.getElementById("newChat");
const chatBox = document.getElementById("chatBox");
const input = document.querySelector(".composer-input");
const sendButton = document.getElementById("sendButton");
const fileInput = document.getElementById("fileInput");
const attachedFilesPreview = document.getElementById("attachedFilesPreview");
// ===== Side Menu =====

const menuButton = document.getElementById("menuButton");
const sideMenu = document.getElementById("sideMenu");
const closeMenu = document.getElementById("closeMenu");
const menuNewChat = document.getElementById("menuNewChat");
const menuTelegram = document.getElementById("menuTelegram");
const menuSearchBtn = document.getElementById("menuSearchBtn");
const menuSearchSection = document.getElementById("menuSearchSection");
const closeSearchBtn = document.getElementById("closeSearchBtn");
const searchInput = document.getElementById("searchInput");
const conversationList = document.getElementById("conversationList");
const modelSelect = document.getElementById("modelSelect");
