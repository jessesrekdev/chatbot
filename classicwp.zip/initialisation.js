
// ===== Initialize =====
renderConversations();
renderConversationMessages();



// ===== Prevent double tap zoom and pinch zoom =====
document.addEventListener('gesturestart', function (e) {
  e.preventDefault();
});
document.addEventListener('dblclick', function (e) {
  e.preventDefault();
});
