// Toggle send button visibility
input.addEventListener("input", () => {
  sendButton.style.display = input.value.trim() ? "flex" : "none";
});

// File input preview (images or file names)
fileInput.addEventListener("change", (e) => {
  attachedFilesPreview.innerHTML = "";
  Array.from(e.target.files).forEach(file => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (file.type.startsWith("image/")) {
        const img = document.createElement("img");
        img.src = event.target.result;
        img.style.width = "60px";
        img.style.height = "60px";
        img.style.objectFit = "cover";
        img.style.borderRadius = "8px";
        attachedFilesPreview.appendChild(img);
      } else {
        const div = document.createElement("div");
        div.innerText = file.name;
        div.style.padding = "8px";
        div.style.border = "1px solid #ccc";
        div.style.borderRadius = "8px";
        attachedFilesPreview.appendChild(div);
      }
    };
    reader.readAsDataURL(file);
  });
});
