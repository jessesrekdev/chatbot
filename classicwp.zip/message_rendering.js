
// Bot message rendering
function appendBotMessage(textRaw, msgId = null) {
  const msg = document.createElement("div");
  msg.className = "chat-message bot-message";
  msg.style.alignSelf = "flex-start";

  // Parse text into segments
  const segments = parseBotResponse(textRaw);

  const contentDiv = document.createElement('div');
  contentDiv.className = 'bot-content';

  // Compose message
  segments.forEach((seg, i) => {
    if (seg.type === "text") {
      const textHtml = renderBold(seg.content)
        .replace(/\n/g, '<br>');
      const textSpan = document.createElement('span');
      textSpan.innerHTML = textHtml;
      contentDiv.appendChild(textSpan);
    }

  });

  msg.appendChild(contentDiv);

  // Bot response actions
  const actions = document.createElement('div');
  actions.className = 'response-actions';

  // Like
  const likeBtn = document.createElement('button');
  likeBtn.className = 'action-like';
  likeBtn.innerHTML = `<svg width="20" height="20" fill="none" stroke="#6e6e80" stroke-width="2" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5c0-2.5 2-4.5 4.5-4.5 2.04 0 3.81 1.23 4.5 3.09C13.69 5.23 15.46 4 17.5 4 20 4 22 6 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>`;
  likeBtn.onclick = () => {
    likeBtn.classList.toggle('selected');
    dislikeBtn.classList.remove('selected');
  };

  // Dislike
  const dislikeBtn = document.createElement('button');
  dislikeBtn.className = 'action-dislike';
  dislikeBtn.innerHTML = `<svg width="20" height="20" fill="none" stroke="#6e6e80" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2.65l1.45 1.32C18.6 8.64 22 11.72 22 15.5c0 2.5-2 4.5-4.5 4.5-2.04 0-3.81-1.23-4.5-3.09C10.31 18.77 8.54 20 6.5 20 4 20 2 18 2 15.5c0-3.78 3.4-6.86 8.55-11.54L12 2.65z"/></svg>`;
  dislikeBtn.onclick = () => {
    dislikeBtn.classList.toggle('selected');
    likeBtn.classList.remove('selected');
  };

  // Copy
  const copyBtn = document.createElement('button');
  copyBtn.className = 'action-copy';
  copyBtn.innerHTML = `<svg width="18" height="18" fill="none" stroke="#10a37f" stroke-width="2" viewBox="0 0 20 20"><rect x="4" y="4" width="12" height="12" rx="2" stroke="#10a37f" fill="none"/><rect x="8" y="8" width="8" height="8" rx="2" stroke="#10a37f" fill="none"/></svg> <span>Copy</span>`;

  // Success tick
  const successBtn = document.createElement('button');
  successBtn.className = 'code-copied-btn';
  successBtn.style.display = 'none';
  successBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M5 10.5l3 3 7-7" stroke="#10a37f" stroke-width="2" fill="none"/></svg> <span>Copied</span>`;

  // Regenerate
  const regenBtn = document.createElement('button');
  regenBtn.className = 'action-regenerate';
  regenBtn.innerHTML = `<svg width="18" height="18" fill="none" stroke="#6e6e80" stroke-width="2" viewBox="0 0 24 24"><path d="M12 5v2m0 10v2m6.364-6.364l1.415 1.414m-12.728 0l-1.414-1.414m12.728-7.072l-1.414 1.414m-7.072 0l-1.414-1.414"/></svg> <span>Regenerate</span>`;
  regenBtn.disabled = true;
  regenBtn.onmouseover = regenBtn.onclick = () => {
    showBubble("Feature coming soon");
  };

  // Copy action
  copyBtn.onclick = () => handleCopyClick(textRaw, copyBtn, successBtn);

  actions.appendChild(likeBtn);
  actions.appendChild(dislikeBtn);
  actions.appendChild(copyBtn);
  actions.appendChild(successBtn);
  actions.appendChild(regenBtn);

  msg.appendChild(actions);
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

// User message rendering
function appendUserMessage(text, attachmentsHTML = "") {
  // Message wrapper
  const msgWrapper = document.createElement("div");
  msgWrapper.className = "chat-message-wrapper";
  msgWrapper.style.alignSelf = "flex-end";

  // Message content
  const msg = document.createElement("div");
  msg.className = "chat-message user-message";
  msg.innerHTML = renderBold(text) + attachmentsHTML;
  msgWrapper.appendChild(msg);

  // Actions container outside message
  const actions = document.createElement('div');
  actions.className = 'response-actions user-actions';

  // Copy button
  const copyBtn = document.createElement('button');
  copyBtn.className = 'action-copy';
  copyBtn.innerHTML = `<svg width="18" height="18" fill="none" stroke="#10a37f" stroke-width="2" viewBox="0 0 20 20">
    <rect x="4" y="4" width="12" height="12" rx="2" stroke="#10a37f" fill="none"/>
    <rect x="8" y="8" width="8" height="8" rx="2" stroke="#10a37f" fill="none"/>
  </svg> <span>Copy</span>`;

  // Success tick
  const successBtn = document.createElement('button');
  successBtn.className = 'code-copied-btn';
  successBtn.style.display = 'none';
  successBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 20 20" fill="none">
    <path d="M5 10.5l3 3 7-7" stroke="#10a37f" stroke-width="2" fill="none"/>
  </svg> <span>Copied</span>`;

  // Edit button (optional)
  const editBtn = document.createElement('button');
  editBtn.className = 'action-edit';
  editBtn.innerHTML = `<svg width="18" height="18" fill="none" stroke="#6e6e80" stroke-width="2" viewBox="0 0 24 24">
    <path d="M4 20h4l10-10a2.828 2.828 0 0 0-4-4L4 16v4z"/>
  </svg> <span>Edit</span>`;
  editBtn.disabled = true; // Feature not implemented yet
  editBtn.onclick = () => showBubble("Feature coming soon");

  // Copy action
  copyBtn.onclick = () => {
    const textToCopy = msg.innerText;
    handleCopyClick(textToCopy, copyBtn, successBtn);
  };

  // Append buttons
  actions.appendChild(copyBtn);
  actions.appendChild(successBtn);
  actions.appendChild(editBtn);

  // Append actions below message
  msgWrapper.appendChild(actions);

  // Add to chat box
  chatBox.appendChild(msgWrapper);
  chatBox.scrollTop = chatBox.scrollHeight;
}