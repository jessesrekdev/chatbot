
// ===== New Chat button =====
newChat.addEventListener("click", () => {
  const newConv = {
    id: Date.now(),
    title: `Chat ${new Date().toLocaleString()}`,
    messages: []
  };
  conversations.unshift(newConv);
  currentConversationId = newConv.id;
  saveConversations();
  renderConversations();
  renderConversationMessages();
});
