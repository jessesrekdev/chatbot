
function showBubble(text) {
  const bubble = document.getElementById('bubble');
  bubble.textContent = text;
  bubble.style.display = 'block';
  setTimeout(() => { bubble.style.display = 'none'; }, 3000);
}

// Utility: Render markdown bold (**bold**)
function renderBold(text) {
  return text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
}

// Utility: Split response into text and code blocks
function parseBotResponse(text) {
  // Split by code block (```)
  const segments = [];
  let remaining = text;
  let idx = 0;

  while (remaining.includes("```")) {
    const start = remaining.indexOf("```");
    if (start > 0) {
      segments.push({ type: "text", content: remaining.slice(0, start) });
    }
    remaining = remaining.slice(start + 3);
    const end = remaining.indexOf("```");
    if (end === -1) break; // malformed
    let codeLang = "";
    // Language specified
    const firstLineBreak = remaining.indexOf('\n');
    if (firstLineBreak !== -1 && firstLineBreak < end) {
      codeLang = remaining.slice(0, firstLineBreak).trim();
      remaining = remaining.slice(firstLineBreak + 1);
    }
    const codeContent = remaining.slice(0, end);
    segments.push({ type: "code", content: codeContent, lang: codeLang });
    remaining = remaining.slice(end + 3);
  }
  if (remaining) segments.push({ type: "text", content: remaining });
  return segments;
}

// Create a utility function for copying text
function copyToClipboard(text) {
  // Try using the modern Clipboard API first
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text)
      .then(() => true)
      .catch(err => {
        console.error('Failed to copy using Clipboard API: ', err);
        return false;
      });
  } else {
    // Fallback for older browsers and insecure contexts
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'absolute';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);

    // Select the text
    textarea.select();
    textarea.setSelectionRange(0, 99999); // For mobile devices

    try {
      // Execute the copy command
      const successful = document.execCommand('copy');
      document.body.removeChild(textarea);
      return successful;
    } catch (err) {
      console.error('Failed to copy text: ', err);
      document.body.removeChild(textarea);
      return false;
    }
  }
}

// Handle copy click with proper mobile support
const handleCopyClick = (text, copyBtn, successBtn) => {
  const result = copyToClipboard(text);

  if (result instanceof Promise) {
    result.then(success => {
      if (success) {
        copyBtn.style.display = 'none';
        successBtn.style.display = 'flex';
        setTimeout(() => {
          successBtn.style.display = 'none';
          copyBtn.style.display = 'flex';
        }, 3000);
      } else {
        showBubble("Copy failed. Please select and copy manually.");
      }
    });
  } else {
    if (result) {
      copyBtn.style.display = 'none';
      successBtn.style.display = 'flex';
      setTimeout(() => {
        successBtn.style.display = 'none';
        copyBtn.style.display = 'flex';
      }, 3000);
    } else {
      showBubble("Copy failed. Please select and copy manually.");
    }
  }
};


// ===== Typing indicator SVG (Instagram style) =====
function createTypingIndicator() {
  const container = document.createElement('span');
  container.className = "typing-indicator";
  container.innerHTML = `
    <svg class="typing-dots" viewBox="0 0 30 16">
      <circle class="typing-dot" cx="5" cy="8" r="4"/>
      <circle class="typing-dot" cx="15" cy="8" r="4"/>
      <circle class="typing-dot" cx="25" cy="8" r="4"/>
    </svg>
    <span style="margin-left:6px;color:#10a37f;font-weight:500;">Thinking</span>
  `;
  return container;
}
